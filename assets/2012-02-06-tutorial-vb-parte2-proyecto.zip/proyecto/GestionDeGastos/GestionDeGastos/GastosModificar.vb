﻿Imports System.Data.OleDb
Public Class frmGastosModificar

    Dim valorFilaSeleccionada As String

    Public Sub New(ByVal fila As String)
        InitializeComponent()
        valorFilaSeleccionada = fila
    End Sub


    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        dtpFecha.Value = Now
        txtConcepto.Text = ""
        txtModalidad.Text = ""
        txtCantidad.Text = ""
        cboCuotaActual.SelectedItem = cboCuotaActual.Items(0)
        cboCuotasTotal.SelectedItem = cboCuotasTotal.Items(0)
    End Sub

    Private Sub frmGastosModificar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        For i = 1 To 300
            cboCuotaActual.Items.Add(i)
            cboCuotasTotal.Items.Add(i)
        Next
        cargarDatos()
    End Sub

    Private Sub cargarDatos()
        'se crea la conexión a la base de datos
        Dim laConexion As OleDbConnection
        laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
        'se crea el objeto de comando SQL
        Dim elComando As OleDbCommand
        elComando = New OleDbCommand("select * from gastos where id = " + valorFilaSeleccionada, laConexion)
        Try
            laConexion.Open()
            'se instancia un objeto para conectar a la tabla
            Dim objetoLector As OleDbDataReader
            objetoLector = elComando.ExecuteReader()
            'se itera sobre la base de datos para ir obteniendo todas las columnas del registro sobre variables temporales
            While (objetoLector.Read())
                Dim campo1 As Date
                Dim campo2, campo3 As String
                Dim campo4 As Double
                Dim campo5, campo6 As Int32
                campo1 = objetoLector.GetDateTime(1)
                campo2 = objetoLector.GetString(2)
                campo3 = objetoLector.GetString(3)
                campo4 = objetoLector.GetDouble(4)
                campo5 = objetoLector.GetInt32(5)
                campo6 = objetoLector.GetInt32(6)

                'se asignan los datos contenidos en las variables a los controles de la interfaz visual
                dtpFecha.Value = campo1
                txtConcepto.Text = campo2
                txtModalidad.Text = campo3
                txtCantidad.Text = campo4
                cboCuotaActual.SelectedItem = cboCuotaActual.Items(campo5 - 1)
                cboCuotasTotal.SelectedItem = cboCuotasTotal.Items(campo6 - 1)
            End While
            objetoLector.Close()

        Catch ex As OleDbException
            MessageBox.Show(ex.Message)
        Finally
            'se cierra la conexión
            laConexion.Close()
        End Try
    End Sub


    Private Sub modifica()
        If IsNumeric(txtCantidad.Text) Then
            'se crea la conexión a la base de datos
            Dim laConexion As OleDbConnection
            laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
            'se guardan en variables los valores ingresados
            Dim campo1 As Date
            Dim campo2, campo3 As String
            Dim campo4 As Double
            Dim campo5, campo6 As Integer
            campo1 = dtpFecha.Value
            campo2 = Trim(txtConcepto.Text)
            campo3 = Trim(txtModalidad.Text)
            campo4 = CDbl(Trim(txtCantidad.Text))
            campo5 = CInt(cboCuotaActual.SelectedItem)
            campo6 = CInt(cboCuotasTotal.SelectedItem)
            'se crea el objeto de comando SQL
            Dim elComando As OleDbCommand
            elComando = New OleDbCommand("update gastos set fecha = @fecha, concepto = @concepto, modalidad = @modalidad, cantidad = @cantidad, cuota_actual = @cuotaact, cuotas_total = @cuotatot where id = " + valorFilaSeleccionada, laConexion)
            elComando.Parameters.Add("@fecha", campo1)
            elComando.Parameters.Add("@concepto", campo2)
            elComando.Parameters.Add("@modalidad", campo3)
            elComando.Parameters.Add("@cantidad", campo4)
            elComando.Parameters.Add("@cuotaact", campo5)
            elComando.Parameters.Add("@cuotatot", campo6)
            Try
                laConexion.Open()
                'se instancia un objeto para conectar a la tabla
                Dim objetoLector As OleDbDataReader
                objetoLector = elComando.ExecuteReader()
                MessageBox.Show("Registro modificado", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information)
                objetoLector.Close()
            Catch ex As OleDbException
                MessageBox.Show(ex.Message)
            Finally
                'se cierra la conexión.
                laConexion.Close()
                Me.Close()
            End Try
        Else
            MessageBox.Show("Los campos numéricos no pueden contener letras ni símbolos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAceptar.Click
        modifica()
    End Sub
End Class