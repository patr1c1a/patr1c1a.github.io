﻿Imports System.Data.OleDb

Public Class frmIngresos

    Private Sub frmIngresos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'IngresosDataSet.ingresos' Puede moverla o quitarla según sea necesario.
        Me.IngresosTableAdapter.Fill(Me.IngresosDataSet.ingresos)

    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        If MessageBox.Show("¿Desea eliminar el registro seleccionado?", "Eliminar", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            elimina(dgvIngresos.CurrentRow.Cells(0).Value)
        End If
        IngresosTableAdapter.Fill(Me.IngresosDataSet.ingresos)
    End Sub

    Private Sub elimina(ByVal pk As String)
        'se crea la conexión a la base de datos
        Dim laConexion As OleDbConnection
        laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
        'se crea el objeto de comando SQL
        Dim elComando As OleDbCommand
        elComando = New OleDbCommand("delete from ingresos where id = " + pk, laConexion)
        Try
            laConexion.Open()
            'se instancia un objeto para conectar a la tabla
            Dim objetoLector As OleDbDataReader
            objetoLector = elComando.ExecuteReader()
            MessageBox.Show("Registro eliminado exitosamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            objetoLector.Close()
        Catch ex As OleDbException
            MessageBox.Show(ex.Message)
        Finally
            'se cierra la conexión
            laConexion.Close()
        End Try
    End Sub


    Private Sub btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregar.Click
        frmIngresosAgregar.Show()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        Dim frmIngresosModificar = New frmIngresosModificar(dgvIngresos.CurrentRow.Cells(0).Value)
        frmIngresosModificar.Show()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        limpiarCampos()
    End Sub

    Private Sub limpiarCampos()
        dtpDesde.Value = Now
        dtpHasta.Value = Now
        txtConcepto.Text = ""
        txtModalidad.Text = ""
    End Sub

    Private Sub btnVerTodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerTodo.Click
        IngresosTableAdapter.Fill(Me.IngresosDataSet.ingresos)
        limpiarCampos()
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Try
            IngresosTableAdapter.Buscar(Me.IngresosDataSet.ingresos, dtpDesde.Value, dtpHasta.Value, txtConcepto.Text, txtModalidad.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class