﻿Imports System.Data.OleDb

Public Class frmIngresosAgregar

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        dtpFecha.Value = Now
        txtConcepto.Text = ""
        txtModalidad.Text = ""
        txtCantidad.Text = ""
    End Sub

    Private Sub btnAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAceptar.Click
        If (Trim(txtConcepto.Text) <> "") And (Trim(txtModalidad.Text) <> "") And (Trim(txtCantidad.Text) <> "") Then
            agregadatos()
        Else
            MessageBox.Show("Debe completar datos antes de agregar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub




    Private Sub agregadatos()
        If IsNumeric(txtCantidad.Text) Then
            'se crea la conexión a la base de datos
            Dim laConexion As OleDbConnection
            laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
            'se guardan en variables los valores ingresados por el usuario en tiempo de ejecución
            Dim campo1, campo2, campo3, campo4 As String
            campo1 = dtpFecha.Value
            campo2 = txtConcepto.Text
            campo3 = txtModalidad.Text()
            campo4 = txtCantidad.Text
            'se crea el objeto de comando SQL
            Dim elComando As OleDbCommand
            'la inserción se realiza utilizando parámetros que se pasan luego asignándole el valor de las variables campo1, campo2, campo3 y campo4.
            elComando = New OleDbCommand("insert into ingresos (fecha,concepto,modalidad,cantidad) values (@fecha,@concepto,@modalidad,@cantidad)", laConexion)
            elComando.Parameters.AddWithValue("@fecha", campo1)
            elComando.Parameters.AddWithValue("@concepto", campo2)
            elComando.Parameters.AddWithValue("@modalidad", campo3)
            elComando.Parameters.AddWithValue("@cantidad", campo4)
            Try
                laConexion.Open()
                'create the datareader object to connect to table
                Dim objetoLector As OleDbDataReader
                objetoLector = elComando.ExecuteReader()
                MessageBox.Show("Registro insertado exitosamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information)
                objetoLector.Close()
            Catch ex As OleDbException
                MessageBox.Show(ex.Message)
            Finally
                'se cierra la conexión
                laConexion.Close()
            End Try
        Else
            MessageBox.Show("Los campos numéricos no pueden contener letras ni símbolos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub



End Class