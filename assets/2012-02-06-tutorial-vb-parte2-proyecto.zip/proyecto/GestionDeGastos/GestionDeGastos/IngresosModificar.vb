﻿Imports System.Data.OleDb
Public Class frmIngresosModificar

    Dim valorFilaSeleccionada As String

    Public Sub New(ByVal fila As String)
        InitializeComponent()
        valorFilaSeleccionada = fila
    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        dtpFecha.Value = Now
        txtConcepto.Text = ""
        txtModalidad.Text = ""
        txtCantidad.Text = ""
    End Sub

    Private Sub btnAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAceptar.Click
        modifica()
    End Sub

    Private Sub IngresosModificar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cargarDatos()
    End Sub

    Private Sub cargarDatos()
        'se crea la conexión a la base de datos
        Dim laConexion As OleDbConnection
        laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
        'se crea el objeto de comando SQL
        Dim elComando As OleDbCommand
        elComando = New OleDbCommand("select * from ingresos where id = " + valorFilaSeleccionada, laConexion)
        Try
            laConexion.Open()
            'se instancia un objeto para conectar a la tabla
            Dim objetoLector As OleDbDataReader
            objetoLector = elComando.ExecuteReader()
            'se itera sobre la base de datos para ir obteniendo todas las columnas del registro sobre variables temporales
            While (objetoLector.Read())
                Dim campo1 As Date
                Dim campo2, campo3 As String
                Dim campo4 As Double
                campo1 = objetoLector.GetDateTime(1)
                campo2 = objetoLector.GetString(2)
                campo3 = objetoLector.GetString(3)
                campo4 = objetoLector.GetDouble(4)

                'se asignan los datos contenidos en las variables a los controles de la interfaz visual
                dtpFecha.Value = campo1
                txtConcepto.Text = campo2
                txtModalidad.Text = campo3
                txtCantidad.Text = campo4
            End While
            objetoLector.Close()

        Catch ex As OleDbException
            MessageBox.Show(ex.Message)
        Finally
            'se cierra la conexión
            laConexion.Close()
        End Try
    End Sub


    Private Sub modifica()
        If IsNumeric(txtCantidad.Text) Then
            'se crea la conexión a la base de datos
            Dim laConexion As OleDbConnection
            laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
            'se guardan en variables los valores ingresados
            Dim campo1 As Date
            Dim campo2, campo3 As String
            Dim campo4 As Double
            campo1 = dtpFecha.Value
            campo2 = Trim(txtConcepto.Text)
            campo3 = Trim(txtModalidad.Text)
            campo4 = CDbl(Trim(txtCantidad.Text))
            'se crea el objeto de comando SQL
            Dim elComando As OleDbCommand
            elComando = New OleDbCommand("update ingresos set fecha = @fecha, concepto = @concepto, modalidad = @modalidad, cantidad = @cantidad where id = " + valorFilaSeleccionada, laConexion)
            elComando.Parameters.Add("@fecha", campo1)
            elComando.Parameters.Add("@concepto", campo2)
            elComando.Parameters.Add("@modalidad", campo3)
            elComando.Parameters.Add("@cantidad", campo4)
            Try
                laConexion.Open()
                'se instancia un objeto para conectar a la tabla
                Dim objetoLector As OleDbDataReader
                objetoLector = elComando.ExecuteReader()
                MessageBox.Show("Registro modificado", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information)
                objetoLector.Close()
            Catch ex As OleDbException
                MessageBox.Show(ex.Message)
            Finally
                'se cierra la conexión.
                laConexion.Close()
                Me.Close()
            End Try
        Else
            MessageBox.Show("Los campos numéricos no pueden contener letras ni símbolos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub




End Class