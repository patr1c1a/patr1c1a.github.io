﻿Public Class Main

    Private Sub btnIngresos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresos.Click
        frmIngresos.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Application.Exit()
    End Sub

    Private Sub btnGastos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGastos.Click
        frmGastos.Show()
    End Sub

    Private Sub btnSaldo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaldo.Click
        frmSaldo.Show()
    End Sub
End Class
