﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSaldo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblSaldoGastos = New System.Windows.Forms.Label()
        Me.lblGastos = New System.Windows.Forms.Label()
        Me.lblSaldoIngresos = New System.Windows.Forms.Label()
        Me.lblIngresos = New System.Windows.Forms.Label()
        Me.lblSaldoTotal = New System.Windows.Forms.Label()
        Me.lblSaldo = New System.Windows.Forms.Label()
        Me.dtpDesde = New System.Windows.Forms.DateTimePicker()
        Me.lblTitulo = New System.Windows.Forms.Label()
        Me.dtpHasta = New System.Windows.Forms.DateTimePicker()
        Me.lblDesde = New System.Windows.Forms.Label()
        Me.lblHasta = New System.Windows.Forms.Label()
        Me.lblPeriodo = New System.Windows.Forms.Label()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.btnVerSaldo = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.lblSaldoGastos)
        Me.Panel1.Controls.Add(Me.lblGastos)
        Me.Panel1.Controls.Add(Me.lblSaldoIngresos)
        Me.Panel1.Controls.Add(Me.lblIngresos)
        Me.Panel1.Controls.Add(Me.lblSaldoTotal)
        Me.Panel1.Controls.Add(Me.lblSaldo)
        Me.Panel1.Location = New System.Drawing.Point(67, 191)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(489, 135)
        Me.Panel1.TabIndex = 102
        '
        'lblSaldoGastos
        '
        Me.lblSaldoGastos.AutoSize = True
        Me.lblSaldoGastos.Font = New System.Drawing.Font("Andorra", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSaldoGastos.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblSaldoGastos.Location = New System.Drawing.Point(408, 55)
        Me.lblSaldoGastos.Name = "lblSaldoGastos"
        Me.lblSaldoGastos.Size = New System.Drawing.Size(23, 20)
        Me.lblSaldoGastos.TabIndex = 107
        Me.lblSaldoGastos.Text = "--"
        '
        'lblGastos
        '
        Me.lblGastos.AutoSize = True
        Me.lblGastos.Font = New System.Drawing.Font("Andorra", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGastos.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblGastos.Location = New System.Drawing.Point(135, 55)
        Me.lblGastos.Name = "lblGastos"
        Me.lblGastos.Size = New System.Drawing.Size(153, 20)
        Me.lblGastos.TabIndex = 106
        Me.lblGastos.Text = "Total de Gastos:"
        '
        'lblSaldoIngresos
        '
        Me.lblSaldoIngresos.AutoSize = True
        Me.lblSaldoIngresos.Font = New System.Drawing.Font("Andorra", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSaldoIngresos.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblSaldoIngresos.Location = New System.Drawing.Point(408, 14)
        Me.lblSaldoIngresos.Name = "lblSaldoIngresos"
        Me.lblSaldoIngresos.Size = New System.Drawing.Size(23, 20)
        Me.lblSaldoIngresos.TabIndex = 105
        Me.lblSaldoIngresos.Text = "--"
        '
        'lblIngresos
        '
        Me.lblIngresos.AutoSize = True
        Me.lblIngresos.Font = New System.Drawing.Font("Andorra", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIngresos.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblIngresos.Location = New System.Drawing.Point(135, 14)
        Me.lblIngresos.Name = "lblIngresos"
        Me.lblIngresos.Size = New System.Drawing.Size(166, 20)
        Me.lblIngresos.TabIndex = 104
        Me.lblIngresos.Text = "Total de Ingresos:"
        '
        'lblSaldoTotal
        '
        Me.lblSaldoTotal.AutoSize = True
        Me.lblSaldoTotal.Font = New System.Drawing.Font("Andorra", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblSaldoTotal.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblSaldoTotal.Location = New System.Drawing.Point(404, 90)
        Me.lblSaldoTotal.Name = "lblSaldoTotal"
        Me.lblSaldoTotal.Size = New System.Drawing.Size(28, 25)
        Me.lblSaldoTotal.TabIndex = 103
        Me.lblSaldoTotal.Text = "--"
        '
        'lblSaldo
        '
        Me.lblSaldo.AutoSize = True
        Me.lblSaldo.Font = New System.Drawing.Font("Andorra", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSaldo.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblSaldo.Location = New System.Drawing.Point(33, 90)
        Me.lblSaldo.Name = "lblSaldo"
        Me.lblSaldo.Size = New System.Drawing.Size(330, 25)
        Me.lblSaldo.TabIndex = 102
        Me.lblSaldo.Text = "Saldo del período seleccionado:"
        '
        'dtpDesde
        '
        Me.dtpDesde.Location = New System.Drawing.Point(256, 79)
        Me.dtpDesde.Name = "dtpDesde"
        Me.dtpDesde.Size = New System.Drawing.Size(200, 20)
        Me.dtpDesde.TabIndex = 103
        Me.dtpDesde.Value = New Date(2011, 3, 28, 9, 37, 0, 0)
        '
        'lblTitulo
        '
        Me.lblTitulo.AutoSize = True
        Me.lblTitulo.Font = New System.Drawing.Font("Andorra", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitulo.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblTitulo.Location = New System.Drawing.Point(261, 9)
        Me.lblTitulo.Name = "lblTitulo"
        Me.lblTitulo.Size = New System.Drawing.Size(100, 38)
        Me.lblTitulo.TabIndex = 104
        Me.lblTitulo.Text = "Saldo"
        '
        'dtpHasta
        '
        Me.dtpHasta.Location = New System.Drawing.Point(256, 128)
        Me.dtpHasta.Name = "dtpHasta"
        Me.dtpHasta.Size = New System.Drawing.Size(200, 20)
        Me.dtpHasta.TabIndex = 105
        Me.dtpHasta.Value = New Date(2011, 3, 28, 9, 38, 0, 0)
        '
        'lblDesde
        '
        Me.lblDesde.AutoSize = True
        Me.lblDesde.Font = New System.Drawing.Font("Andorra", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDesde.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblDesde.Location = New System.Drawing.Point(161, 82)
        Me.lblDesde.Name = "lblDesde"
        Me.lblDesde.Size = New System.Drawing.Size(56, 17)
        Me.lblDesde.TabIndex = 106
        Me.lblDesde.Text = "Desde:"
        '
        'lblHasta
        '
        Me.lblHasta.AutoSize = True
        Me.lblHasta.Font = New System.Drawing.Font("Andorra", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHasta.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblHasta.Location = New System.Drawing.Point(161, 128)
        Me.lblHasta.Name = "lblHasta"
        Me.lblHasta.Size = New System.Drawing.Size(54, 17)
        Me.lblHasta.TabIndex = 107
        Me.lblHasta.Text = "Hasta:"
        '
        'lblPeriodo
        '
        Me.lblPeriodo.AutoSize = True
        Me.lblPeriodo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPeriodo.Font = New System.Drawing.Font("Andorra", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPeriodo.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.lblPeriodo.Location = New System.Drawing.Point(61, 102)
        Me.lblPeriodo.Name = "lblPeriodo"
        Me.lblPeriodo.Size = New System.Drawing.Size(78, 22)
        Me.lblPeriodo.TabIndex = 108
        Me.lblPeriodo.Text = "Período"
        '
        'btnSalir
        '
        Me.btnSalir.BackColor = System.Drawing.Color.CadetBlue
        Me.btnSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalir.Location = New System.Drawing.Point(566, 9)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(45, 30)
        Me.btnSalir.TabIndex = 109
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = False
        '
        'btnVerSaldo
        '
        Me.btnVerSaldo.BackColor = System.Drawing.Color.DarkSlateGray
        Me.btnVerSaldo.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnVerSaldo.Location = New System.Drawing.Point(487, 91)
        Me.btnVerSaldo.Name = "btnVerSaldo"
        Me.btnVerSaldo.Size = New System.Drawing.Size(75, 46)
        Me.btnVerSaldo.TabIndex = 110
        Me.btnVerSaldo.Text = "Ver Saldo"
        Me.btnVerSaldo.UseVisualStyleBackColor = False
        '
        'frmSaldo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(623, 357)
        Me.Controls.Add(Me.btnVerSaldo)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.lblPeriodo)
        Me.Controls.Add(Me.lblHasta)
        Me.Controls.Add(Me.lblDesde)
        Me.Controls.Add(Me.dtpHasta)
        Me.Controls.Add(Me.lblTitulo)
        Me.Controls.Add(Me.dtpDesde)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmSaldo"
        Me.Text = "Saldo"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblSaldoTotal As System.Windows.Forms.Label
    Friend WithEvents lblSaldo As System.Windows.Forms.Label
    Friend WithEvents dtpDesde As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblTitulo As System.Windows.Forms.Label
    Friend WithEvents lblSaldoGastos As System.Windows.Forms.Label
    Friend WithEvents lblGastos As System.Windows.Forms.Label
    Friend WithEvents lblSaldoIngresos As System.Windows.Forms.Label
    Friend WithEvents lblIngresos As System.Windows.Forms.Label
    Friend WithEvents dtpHasta As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDesde As System.Windows.Forms.Label
    Friend WithEvents lblHasta As System.Windows.Forms.Label
    Friend WithEvents lblPeriodo As System.Windows.Forms.Label
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents btnVerSaldo As System.Windows.Forms.Button
End Class
