﻿Imports System.Data.OleDb
Public Class frmSaldo

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnVerSaldo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerSaldo.Click
        If dtpDesde.Value <= dtpHasta.Value Then
            Dim totalIngresos As Double = 0
            Dim totalGastos As Double = 0
            obtenerIngresosTotal(totalIngresos)
            lblSaldoIngresos.Text = totalIngresos
            obtenerGastosTotal(totalGastos)
            lblSaldoGastos.Text = totalGastos
            lblSaldoTotal.Text = totalIngresos - totalGastos
            If totalIngresos - totalGastos < 0 Then
                lblSaldoTotal.ForeColor = Color.Red
            End If
        Else
            MessageBox.Show("La fecha inicial no puede ser mayor a la fecha final", "Rango de fecha incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub


    Private Sub obtenerIngresosTotal(ByRef total As Double)
        'se crea la conexión a la base de datos
        Dim laConexion As OleDbConnection
        laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
        'se crea el objeto de comando SQL
        Dim elComando As OleDbCommand
        elComando = New OleDbCommand("select * from ingresos where fecha between @fecha1 and @fecha2", laConexion)
        elComando.Parameters.AddWithValue("@fecha1", dtpDesde.Value)
        elComando.Parameters.AddWithValue("@fecha2", dtpHasta.Value)
        Try
            laConexion.Open()
            'se instancia un objeto para conectar a la tabla
            Dim objetoLector As OleDbDataReader
            objetoLector = elComando.ExecuteReader()
            'se itera sobre la base de datos para ir obteniendo los valores de la columna requerida y sumándolos a una variable
            While (objetoLector.Read())
                total = total + objetoLector.GetDouble(4)
            End While
            objetoLector.Close()
        Catch ex As OleDbException
            MessageBox.Show(ex.Message)
        Finally
            'se cierra la conexión
            laConexion.Close()
        End Try
    End Sub


    Private Sub obtenerGastosTotal(ByRef total As Double)
        'se crea la conexión a la base de datos
        Dim laConexion As OleDbConnection
        laConexion = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\proyecto\gestion.mdb")
        'se crea el objeto de comando SQL
        Dim elComando As OleDbCommand
        elComando = New OleDbCommand("select * from gastos where fecha between @fecha1 and @fecha2", laConexion)
        elComando.Parameters.AddWithValue("@fecha1", dtpDesde.Value)
        elComando.Parameters.AddWithValue("@fecha2", dtpHasta.Value)
        Try
            laConexion.Open()
            'se instancia un objeto para conectar a la tabla
            Dim objetoLector As OleDbDataReader
            objetoLector = elComando.ExecuteReader()
            'se itera sobre la base de datos para ir obteniendo los valores de la columna requerida y sumándolos a una variable
            While (objetoLector.Read())
                total = total + objetoLector.GetDouble(4)
            End While
            objetoLector.Close()
        Catch ex As OleDbException
            MessageBox.Show(ex.Message)
        Finally
            'se cierra la conexión
            laConexion.Close()
        End Try
    End Sub

    Private Sub frmSaldo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dtpDesde.Value = Now
        dtpHasta.Value = Now
    End Sub
End Class
