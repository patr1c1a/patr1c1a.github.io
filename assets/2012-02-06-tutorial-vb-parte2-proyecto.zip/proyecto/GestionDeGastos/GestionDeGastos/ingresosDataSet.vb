﻿Partial Class ingresosDataSet
End Class

Namespace ingresosDataSetTableAdapters

    Partial Public Class ingresosTableAdapter
    End Class
End Namespace
