package Carreras;


/* Representa un alumno */
public class Alumno {

	private String nombre;
	private int legajo;
	
	
	/* Constructor gen�rico */
	public Alumno(){
		super();
	}
	
	
	/* Constructor con par�metros */
	public Alumno(String nombre, int legajo){
		super();
		this.setNombre(nombre);
		this.setLegajo(legajo);
	}
	
	
	
	
	/* Getters y Setters de los atributos */
	
	public String getNombre() {
		return nombre;
	}
	
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	public int getLegajo() {
		return legajo;
	}
	
	
	public void setLegajo(int legajo) {
		this.legajo = legajo;
	}

	
	
}
