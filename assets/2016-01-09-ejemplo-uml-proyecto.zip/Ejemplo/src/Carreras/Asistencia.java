package Carreras;

import java.util.ArrayList;
import java.util.Date;


/* Representa un conjunto de todos los alumnos que asistieron en determinada fecha a una clase de una materia.
 * Se relaciona con un objeto Materia a trav�s de una colecci�n de Asistencias en la Materia. */
public class Asistencia {

	
	private Date fecha;
	private ArrayList<Alumno> alumnos;
	
	
	
	/* Constructor gen�rico */
	public Asistencia(){
		super();
		//Instancia una colecci�n vac�a y la asigna al atributo
		this.setAlumnos(new ArrayList<Alumno>());
	}
	
	
	/* Constructor con par�metros */
	public Asistencia(Date fecha){
		super();
		this.setFecha(fecha);
		//Instancia una colecci�n vac�a y la asigna al atributo
		this.setAlumnos(new ArrayList<Alumno>());
	}

	
	
	
	
	
	/* Agrega un nuevo alumno a la colecci�n de alumnos.
	 * Utiliza el m�todo "add" de ArrayList para agregar el objeto "alumno" de tipo "Alumno" */
	public void agregarAlumno(Alumno alumno){
		this.getAlumnos().add(alumno);
	}
	
	
	
	
	/* Elimina una nueva carrera universitaria a la colecci�n de carreras.
	 * Utiliza el m�todo "remove" de ArrayList para ubicar y eliminar el objeto "carrera" de tipo "Carrera" */
	public void eliminarAlumno(Alumno alumno){
		this.getAlumnos().remove(alumno);
	}
	
	
	
	
	/* Devuelve la cantidad de alumnos en la colecci�n. 
	 * 	Para esto, cuenta los elementos de la colecci�n de alumnos, utilizando el m�todo "size" de ArrayList */
	public int contarAlumnos(){
		return this.getAlumnos().size();
	}
	
	
	
	/* Getters y Setters de los atributos */

	public Date getFecha() {
		return fecha;
	}


	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}


	public ArrayList<Alumno> getAlumnos() {
		return alumnos;
	}


	public void setAlumnos(ArrayList<Alumno> alumnos) {
		this.alumnos = alumnos;
	}
	
	
	
	
	
}
