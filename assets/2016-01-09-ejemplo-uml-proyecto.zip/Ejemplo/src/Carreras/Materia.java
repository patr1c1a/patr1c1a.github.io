package Carreras;

import java.util.ArrayList;
import java.util.Date;

/* Representa cada una de las materias de una carrera universitaria */
public class Materia {

	private String nombre;
	private Profesor titular;
	private ArrayList<Alumno> alumnos;
	private ArrayList<Asistencia> asistencias;
	
	
	/* Constructor gen�rico */
	public Materia(){
		super();
		//Instancia colecciones vac�as y las asigna a los atributos correspondientes
		this.setAlumnos(new ArrayList<Alumno>());
		this.setAsistencias(new ArrayList<Asistencia>());
	}
	
	
	/* Constructor con par�metros */
	public Materia(String nombre){
		super();
		this.setNombre(nombre);
		//Instancia colecciones vac�as y las asigna a los atributos correspondientes
		this.setAlumnos(new ArrayList<Alumno>());
		this.setAsistencias(new ArrayList<Asistencia>());
	}
	
	
	/* Constructor con par�metros */
	public Materia(String nombre, Profesor titular){
		super();
		this.setNombre(nombre);
		this.setTitular(titular);
		//Instancia colecciones vac�as y las asigna a los atributos correspondientes
		this.setAlumnos(new ArrayList<Alumno>());
		this.setAsistencias(new ArrayList<Asistencia>());
	}
	
	
	
	
	/* Calcula cu�ntos alumnos hay inscriptos en la materia.
	* Para esto, cuenta los elementos de la colecci�n de alumnos, utilizando el m�todo "size" de TreeSet */
	public int calcularInscriptos(){
		return this.getAlumnos().size();
	}
	
	
	
	
	/* Calcula el porcentaje de asistencia y lo retorna en un valor entre 0 y 1.
	*  Para esto recorre la colecci�n de asistencias buscando el elemento que coincida con la fecha indicada
	*  Una vez encontrado, calcula el porcentaje utilizando la cantidad de alumnos asistentes en esa fecha y
	*  el total de alumnos inscriptos en la materia. Si no encuentra un elemento coincidente, devuelve 0 */
	public double calcularAsistencia(Date fecha){
		for (Asistencia asist : this.getAsistencias()){
			if ((asist.getFecha()).compareTo(fecha) == 0)
				return (double)asist.contarAlumnos() / (double)this.calcularInscriptos();
		}
		return 0;
	}
	
	
	
	/* Agrega un nuevo alumno a la colecci�n de alumnos.
	 * Utiliza el m�todo "add" de ArrayList para agregar el objeto "alumno" de tipo "Alumno" */
	public void agregarAlumno(Alumno alumno){
		this.getAlumnos().add(alumno);
	}
	
	
	
	
	/* Elimina una nueva carrera universitaria a la colecci�n de carreras.
	 * Utiliza el m�todo "remove" de ArrayList para ubicar y eliminar el objeto "carrera" de tipo "Carrera" */
	public void eliminarAlumno(Alumno alumno){
		this.getAlumnos().remove(alumno);
	}
	
	
	
	
	/* Agrega una nueva asistencia a la colecci�n de asistencias.
	 * Utiliza el m�todo "add" de ArrayList para agregar el objeto "alumno" de tipo "Alumno" */
	public void agregarAsistencia(Asistencia asistencia){
		this.getAsistencias().add(asistencia);
	}
	
	
	
	
	/* Elimina una nueva carrera universitaria a la colecci�n de carreras.
	 * Utiliza el m�todo "remove" de ArrayList para ubicar y eliminar el objeto "carrera" de tipo "Carrera" */
	public void eliminarAsistencia(Asistencia asistencia){
		this.getAsistencias().remove(asistencia);
	}
	
	
	
	
	
	
	
	
	/* Getters y Setters de los atributos */
	
	public String getNombre() {
		return nombre;
	}
	
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	public Profesor getTitular() {
		return titular;
	}
	
	
	public void setTitular(Profesor titular) {
		this.titular = titular;
	}
	
	
	public ArrayList<Alumno> getAlumnos() {
		return alumnos;
	}
	
	
	public void setAlumnos(ArrayList<Alumno> alumno) {
		this.alumnos = alumno;
	}
	
	
	public ArrayList<Asistencia> getAsistencias() {
		return asistencias;
	}
	
	
	public void setAsistencias(ArrayList<Asistencia> asistencia) {
		this.asistencias = asistencia;
	}
	
	
}
