from funciones import *


listado=[]
while (True):
    print("Seleccionar opción deseada")
    print("1. Cargar palabras")
    print("2. Jugar")
    print("3. Salir")
    opcion=int(input())
    if opcion==1:
        listado=cargarPalabras(listado)
    elif opcion==2:
        letrasAdivinadas=set()
        intentosRestantes=6
        palabra=seleccionarPalabra(listado)
        print("La palabra tiene ", len(palabra), " letras.")
        while intentosRestantes > 0:
            if palabraCompleta(palabra, letrasAdivinadas):
                print("Ganaste!")
                break
            mostrar=progresoDelJuego(palabra, letrasAdivinadas)
            print(mostrar)
            letra=leerLetra(letrasAdivinadas)
            letrasAdivinadas.add(letra)
            if letra not in palabra:
                intentosRestantes-=1
                print("NOP! Intentos restantes: ", intentosRestantes)
            else:
                print("SIP!")
    elif opcion==3:
        break
