"""
CONSIGNA:
Escribir las siguientes funciones:

cargarPalabras:
    -Parámetros: lista
    -Retorna: lista (con las palabras disponibles para jugar)
    -Qué hace: En un bucle, solicita al usuario que ingrese palabras y las va agregando a la lista.
    Por cada palabra se eliminan los espacios en blanco a izquierda y derecha.
    La palabra se pasa a mayúsculas antes de insertarse en la lista.
    La carga termina con una condición de corte que se informa al usuario.

progresoDelJuego:
    -Parámetros: string (palabra en juego), conjunto con las letras ya arriesgadas.
    -Retorna: string donde las letras adivinadas se muestran y las no adivinadas se reemplazan por "_".
    -Qué hace: forma un string donde, por cada letra de la palabra en juego, verifica si esa letra ya fue adivinada. En ese caso la coloca en el string a formar. En caso contrario, coloca un "_".

leerLetra:
-Parámetros: conjunto con las letras ya arriesgadas.
    -Retorna: letra arriesgada.
    -Qué hace: En un bucle le pide al usuario que ingrese una letra para adivinar.
    La letra se convierte a mayúscula porque las palabras están todas en mayúsculas.
    También se eliminan los espacios a izquierda y derecha y se continúa sólo si el string leído tiene 1 solo carácter (si es una sola letra).
Si la letra ya había sido ingresada anteriormente, se le informa al usuario y se le vuelve a pedir una letra.
    Cuando el usuario ingresa una letra válida, se retorna.

palabraCompleta:
    -Parámetros: palabra en juego, conjunto con las letras ya arriesgadas.
    -Retorna: True si ya se adivinaron todas las letras de la palabra en juego, False en caso contrario.
    -Qué hace: Verifica cada letra de la palabra en juego y retorna False si encuentra una letra que está en la palabra y que no fue arriesgada por el jugador.
    Si todas las letras de la palabra en juego fueron arriesgadas por el jugador, entonces retorna True porque el jugador ya adivinó la palabra completa.
"""


import random


def seleccionarPalabra(listadoPalabras):
    return listadoPalabras[random.randint(0, len(listadoPalabras)-1)]


def cargarPalabras(listadoPalabras):
    print("Ingresar palabra ('fin' para cortar): ")
    palabra=input()
    palabra=palabra.upper().strip()
    while palabra!="FIN":
        listadoPalabras.append(palabra)
        print("Ingresar palabra ('fin' para cortar): ")
        palabra=input()
        palabra=palabra.upper().strip()
    return listadoPalabras


def progresoDelJuego(palabra, letrasAdivinadas):
    adivinado=""
    for letra in palabra:
        if letra in letrasAdivinadas:
            adivinado+=letra
        else:
            adivinado+="_"
    return adivinado


def leerLetra(letrasAdivinadas):
    while (True):
        print("Adivinar letra: ")
        letra=input()
        letra=letra.upper().strip()
        if len(letra)==1:
            if letra in letrasAdivinadas:
                print("Ya habías dicho esa letra")
            else:
                break
    return letra


def palabraCompleta(palabra, letrasAdivinadas):
    for letra in palabra:
        if letra not in letrasAdivinadas:
            return False
    return True


listado=[]
while (True):
    print("Seleccionar opción deseada")
    print("1. Cargar palabras")
    print("2. Jugar")
    print("3. Salir")
    opcion=int(input())
    if opcion==1:
        listado=cargarPalabras(listado)
    elif opcion==2:
        letrasAdivinadas=set()
        intentosRestantes=6
        palabra=seleccionarPalabra(listado)
        print("La palabra tiene ", len(palabra), " letras.")
        while intentosRestantes > 0:
            if palabraCompleta(palabra, letrasAdivinadas):
                print("Ganaste!")
                break
            mostrar=progresoDelJuego(palabra, letrasAdivinadas)
            print(mostrar)
            letra=leerLetra(letrasAdivinadas)
            letrasAdivinadas.add(letra)
            if letra not in palabra:
                intentosRestantes-=1
                print("NOP! Intentos restantes: ", intentosRestantes)
            else:
                print("SIP!")
    elif opcion==3:
        break
            
        
