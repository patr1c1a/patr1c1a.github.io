import random

def seleccionarPalabra(listadoPalabras):
    return listadoPalabras[random.randint(0, len(listadoPalabras)-1)]

def cargarPalabras(listadoPalabras):
    palabra=input("Ingresar palabra ('fin' para cortar): ").upper().strip()
    while palabra!="FIN":
        listadoPalabras.append(palabra)
        palabra=input("Ingresar palabra ('fin' para cortar): ").upper().strip()
    return listadoPalabras


def progresoDelJuego(palabra, letrasAdivinadas):
    adivinado=""
    for letra in palabra:
        if letra in letrasAdivinadas:
            adivinado+=letra
        else:
            adivinado+="_"
    return adivinado


def leerLetra(letrasAdivinadas):
    while (True):
        letra=input("Adivinar letra: ").upper().strip()
        if len(letra)==1:
            if letra in letrasAdivinadas:
                print("Ya habías dicho esa letra")
            else:
                break
    return letra


def palabraCompleta(palabra, letrasAdivinadas):
    for letra in palabra:
        if letra not in letrasAdivinadas:
            return False
    return True
