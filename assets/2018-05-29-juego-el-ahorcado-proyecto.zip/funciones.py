"""
CONSIGNA:
Agregar al final de este archivo las siguientes funciones (sin modificar el código existente):

cargarPalabras:
    -Parámetros: lista
    -Retorna: lista (con las palabras disponibles para jugar)
    -Qué hace: En un bucle, solicita al usuario que ingrese palabras y las va agregando a la lista.
    Por cada palabra se eliminan los espacios en blanco a izquierda y derecha.
    La palabra se pasa a mayúsculas antes de insertarse en la lista.
    La carga termina con una condición de corte que se informa al usuario.

progresoDelJuego:
    -Parámetros: string (palabra en juego), conjunto con las letras ya arriesgadas.
    -Retorna: string donde las letras adivinadas se muestran y las no adivinadas se reemplazan por "_".
    -Qué hace: forma un string donde, por cada letra de la palabra en juego, verifica si esa letra ya fue adivinada. En ese caso la coloca en el string a formar. En caso contrario, coloca un "_".

leerLetra:
-Parámetros: conjunto con las letras ya arriesgadas.
    -Retorna: letra arriesgada.
    -Qué hace: En un bucle le pide al usuario que ingrese una letra para adivinar.
    La letra se convierte a mayúscula porque las palabras están todas en mayúsculas.
    También se eliminan los espacios a izquierda y derecha y se continúa sólo si el string leído tiene 1 solo carácter (si es una sola letra).
Si la letra ya había sido ingresada anteriormente, se le informa al usuario y se le vuelve a pedir una letra.
    Cuando el usuario ingresa una letra válida, se retorna.

palabraCompleta:
    -Parámetros:
    -Retorna: True si ya se adivinaron todas las letras de la palabra en juego, False en caso contrario.
    -Qué hace: Verifica cada letra de la palabra en juego y retorna False si encuentra una letra que está en la palabra y que no fue arriesgada por el jugador.
    Si todas las letras de la palabra en juego fueron arriesgadas por el jugador, entonces retorna True porque el jugador ya adivinó la palabra completa.
"""

import random

def seleccionarPalabra(listadoPalabras):
    return listadoPalabras[random.randint(0, len(listadoPalabras)-1)]
