'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Dadas las variables a = 41 y b = 5, escribí las instrucciones necesarias para obtener el resultado de su suma, su resta, su multiplicación, el cociente, el cociente entero y el resto de la división entre a y b.
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

		
    def suma(self):
        a=41
        b=5
        c=   #completar con la instrucción necesaria para que la variable c guarde la suma de a y b
        self.ventana.resultado.configure(text=c)

    def resta(self):
        a=41
        b=5
        c=   #completar con la instrucción necesaria para que la variable c guarde la resta de a y b
        self.ventana.resultado.configure(text=c)

    def multiplicacion(self):
        a=41
        b=5
        c=   #completar con la instrucción necesaria para que la variable c guarde la multiplicación de a y b
        self.ventana.resultado.configure(text=c)

    def division(self):
        a=41
        b=5
        c=   #completar con la instrucción necesaria para que la variable c guarde el cociente entre a y b
        self.ventana.resultado.configure(text=c)

    def divisionParteEntera(self):
        a=41
        b=5
        c=   #completar con la instrucción necesaria para que la variable c guarde el cociente entero entre a y b
        self.ventana.resultado.configure(text=c)

    def divisionResto(self):
        a=41
        b=5
        c=   #completar con la instrucción necesaria para que la variable c guarde el resto de la división entre a y b
        self.ventana.resultado.configure(text=c)
