'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Utilizá las operaciones matemáticas más apropiada para obtener, del número 25849,
a) Solo el último dígito (9)
b) Los dos últimos dígitos (49)
c) Los 3 últimos dígitos (849)
d) Todos los dígitos, excepto el último (2584)
e) El primer dígito (2)
f) Los dos primeros dígitos (25)
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

		
    def ultimoDigito(self):
        r=   #completar con la instrucción necesaria para que la variable r guarde el último dígito de 25849
        self.ventana.resultado.configure(text=r)

    def dosUltimos(self):
        r=   #completar con la instrucción necesaria para que la variable r guarde los dos últimos dígitos de 25849
        self.ventana.resultado.configure(text=r)

    def tresUltimos(self):
        r=   #completar con la instrucción necesaria para que la variable r guarde los tres últimos dígitos de 25849
        self.ventana.resultado.configure(text=r)

    def exceptoUltimo(self):
        r=   #completar con la instrucción necesaria para que la variable r guarde todos los dígitos de 25849, excepto el último
        self.ventana.resultado.configure(text=r)

    def primerDigito(self):
        r=   #completar con la instrucción necesaria para que la variable r guarde el primer dígito de 25849
        self.ventana.resultado.configure(text=r)

    def primerosDos(self):
        r=   #completar con la instrucción necesaria para que la variable r guarde los dos primeros dígitos de 25849
        self.ventana.resultado.configure(text=r)
