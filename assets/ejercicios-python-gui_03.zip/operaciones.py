'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Dadas las variables nombre = "Francisco" y apellido = "Gimenez", como harías para mostrar...
a) Las dos cadenas concatenadas, nombre y apellido, separados por un espacio. Ejemplo: "Francisco Gimenez"
b) Las dos cadenas concatenadas y separadas por ", ". Ejemplo: "Gimenez, Francisco"
c) La frase "¡Bienvenido, Francisco Gimenez!" (usando los valores de las variables nombre y apellido)
d) Nombre y apellido, separados por un espacio y completamente en mayúsculas. Ejemplo: "FRANCISCO GIMENEZ"
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

        
		
    def nombre_apellido(self):
        nombre = "Francisco"
        apellido = "Gimenez"
        s=    #completar con la instrucción necesaria para que la variable s guarde la concatenación de nombre y apellido, separados por un espacio
        self.ventana.resultado.configure(text=s)

    def apellido_nombre(self):
        nombre = "Francisco"
        apellido = "Gimenez"
        s=    #completar con la instrucción necesaria para que la variable s guarde la concatenación de apellido y nombre, separadas por ", "
        self.ventana.resultado.configure(text=s)

    def bienvenida(self):
        nombre = "Francisco"
        apellido = "Gimenez"
        s=    #completar con la instrucción necesaria para que la variable s guarde "¡Bienvenido, Francisco Gimenez!"
        self.ventana.resultado.configure(text=s)

    def mayusculas(self):
        nombre = "Francisco"
        apellido = "Gimenez"
        s=    #completar con la instrucción necesaria para que la variable s guarde "FRANCISCO GIMENEZ"
        self.ventana.resultado.configure(text=s)
