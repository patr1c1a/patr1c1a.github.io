'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Teniendo las siguientes variables:
cadena1 = "El que lee"
cadena2 = " mucho"
cadena3 = " y anda mucho,"
cadena4 = " y sabe mucho."
cadena5 = " ve mucho"
cadena6 = "Esta es una frase de Don Quijote"
a) Construir la cadena "frase de Don Quijote: El que lee mucho y anda mucho, ve mucho y sabe mucho." a partir de las variables dadas.
b) ¿En qué posición de la cadena anterior está la palabra "anda"?
c) Usar una operación que de como resultado la primera posición en que aparece la letra "e" en cadena1.
d) Usar una operación que de como resultado "DON QUIJOTE" a partir de cadena6.
e) Obtener True o False (o bien 1 o 0) para saber si cadena2 contiene algún espacio.
f) Usar una operación que de como resultado la posición de "o" en cadena4[:6] y observar qué sucede al no encontrarla.
g) Mostrar cuántos espacios tiene la cadena construida en el inciso a.
''' 

cadena1 = "El que lee"
cadena2 = " mucho"
cadena3 = " y anda mucho,"
cadena4 = " y sabe mucho."
cadena5 = " ve mucho"
cadena6 = "Esta es una frase de Don Quijote"

class Operaciones:

    def __init__(self, ventana):
        self.ventana=ventana
		
    def inciso_a(self):
        s=     #completar con la instrucción necesaria para que la variable s guarde la cadena "frase de Don Quijote: El que lee mucho y anda mucho, ve mucho y sabe mucho."
        self.ventana.resultado.configure(text=s)

    def inciso_b(self):
        #si es necesario, crear una variable        
        s=                          #completar con la instrucción necesaria para que la variable s guarde en qué posición de la cadena completa está la palabra "anda"
        self.ventana.resultado.configure(text=s)

    def inciso_c(self):
        s=                          #completar con la instrucción necesaria para que la variable s guarde la primera posición en que aparece la letra "e" en cadena1
        self.ventana.resultado.configure(text=s)

    def inciso_d(self):
        s=                          #completar con la instrucción necesaria para obtener "DON QUIJOTE" a partir de cadena6
        self.ventana.resultado.configure(text=s)

    def inciso_e(self):
        s=                          #completar con la instrucción necesaria para que la variable s indique si cadena2 contiene algún espacio
        self.ventana.resultado.configure(text=s)

    def inciso_f(self):
        s=                          #completar con la instrucción necesaria para que la variable s guarde la posición de la letra "o" en cadena4[:6]
        self.ventana.resultado.configure(text=s)

    def inciso_g(self):
        #si es necesario, crear una variable
        s=                          #completar con la instrucción necesaria para que la variable s guarde cuántos espacios tiene la cadena "frase de Don Quijote: El que lee mucho y anda mucho, ve mucho y sabe mucho."
        self.ventana.resultado.configure(text=s)
