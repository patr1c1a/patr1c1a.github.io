'''
Atención: No modificar este archivo.
Abrir el archivo operaciones.py  y, de acuerdo a la consigna dada, completar únicamente donde aparecen comentarios indicados con #
Luego ejecutar este programa python.
'''


from tkinter import *
from operaciones import *

class Interfaz:
    def __init__(self, ventana):
        self.ventana = ventana
        operaciones=Operaciones(self)
        
        self.resultado = Label(ventana, text="", width=35, height=2, bg="white", font=("Arial", 12))
        self.resultado.pack(padx=15, pady=10, side=TOP, fill=BOTH)
        
        self.arriba=Frame(self.ventana)
        self.arriba.pack(side=TOP)
        self.cadenas = Label(self.arriba, text='cadena1: "El que lee"\ncadena2: " mucho"\ncadena3: " y anda mucho,"\ncadena4: " y sabe mucho."\ncadena5: " ve mucho"\ncadena6: "Esta es una frase de Don Quijote"', justify=LEFT, font=("Verdana", 15))
        self.cadenas.pack(padx=20)

        self.abajo=Frame(self.ventana)
        self.abajo.pack(padx=20, side=TOP)
        self.btn1 = Button(self.abajo, text="Frase completa", bg="moccasin", height=2, width=30, command=operaciones.inciso_a)
        self.btn2 = Button(self.abajo, text="Posición de 'anda'\nen la frase completa", bg="moccasin", height=2, width=30, command=operaciones.inciso_b)
        self.btn3 = Button(self.abajo, text="Dónde está 'e' en cadena1", bg="moccasin", height=2, width=30, command=operaciones.inciso_c)
        self.btn4 = Button(self.abajo, text="Obtener 'DON QUIJOTE' de cadena6", bg="moccasin", height=2, width=30, command=operaciones.inciso_d)
        self.btn5 = Button(self.abajo, text="¿cadena2 contiene espacios?", bg="moccasin", height=2, width=30, command=operaciones.inciso_e)
        self.btn6 = Button(self.abajo, text="Dónde está 'o' en cadena4[:6]", bg="moccasin", height=2, width=30, command=operaciones.inciso_f)
        self.btn7 = Button(self.abajo, text="Cantidad de espacios\nen la frase completa", bg="moccasin", height=2, width=30, command=operaciones.inciso_g)
        self.btn1.pack()
        self.btn2.pack()
        self.btn3.pack()
        self.btn4.pack()
        self.btn5.pack()
        self.btn6.pack()
        self.btn7.pack()

def main(): 
    ventana = Tk()
    ventana.geometry('600x550')
    ventana.resizable(width=False, height=False)
    ventana.title("Manipulando strings")
    app = Interfaz(ventana)
    ventana.mainloop()


if __name__ == '__main__':
    main()
