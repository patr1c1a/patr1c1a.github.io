'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Si tenemos la cadena frase='Hasta la persona más pequeña puede cambiar el curso del futuro', indicá operaciones para obtener:
a) La cadena 'más pequeña' a partir de la variable frase.
b) Los primeros 5 caracteres de frase.
c) Los últimos 6 caracteres de frase.
d) Los caracteres ubicados en las posiciones pares de frase.
e) La cadena 'o repra' a partir de frase leída en forma inversa.
f) Cuántas ocurrencias de la letra 'a' existen en frase (incluir la 'a' con y sin acentos)
''' 

frase='Hasta la persona más pequeña puede cambiar el curso del futuro'

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana
		
    def inciso_a(self):
        r=   #completar con la instrucción necesaria para que la variable r contenga la rebanada 'más pequeña' a partir de la variable frase
        self.ventana.resultado.configure(text=r)

    def inciso_b(self):
        r=   #completar con la instrucción necesaria para que la variable r contenga los primeros 5 caracteres de la variable frase
        self.ventana.resultado.configure(text=r)

    def inciso_c(self):
        r=   #completar con la instrucción necesaria para que la variable r contenga los últimos 6 caracteres de la variable frase
        self.ventana.resultado.configure(text=r)

    def inciso_d(self):
        r=   #completar con la instrucción necesaria para que la variable r contenga los caracteres pares de la variable frase
        self.ventana.resultado.configure(text=r)

    def inciso_e(self):
        r=   #completar con la instrucción necesaria para que la variable r contenga la rebanada 'o repra' a partir de la variable frase
        self.ventana.resultado.configure(text=r)

    def inciso_f(self):
        r=   #completar con la instrucción necesaria para que la variable r contenga la cantidad de 'a' y 'á' de la cadena guardada en frase
        self.ventana.resultado.configure(text=r)
