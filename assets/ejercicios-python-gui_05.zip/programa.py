'''
Atención: No modificar este archivo.
Abrir el archivo operaciones.py y, de acuerdo a la consigna dada, completar únicamente donde aparecen comentarios indicados con #
Luego ejecutar este programa python.
'''


from tkinter import *
from operaciones import *

class Interfaz:
    def __init__(self, ventana):
        self.ventana = ventana
        operaciones=Operaciones(self)
        
        self.texto = Label(ventana, text="'Hasta la persona más pequeña puede cambiar el curso del futuro'", font=("Verdana", 19), wraplength=450, justify="center")
        self.texto.pack(padx=15, pady=(25,10), side=TOP)
        self.resultado = Label(ventana, text="rebanada: ", width=30, height=2, bg="white", font=("Arial", 14))
        self.resultado.pack(padx=15, pady=(5,35), side=TOP)

        self.inferior=Frame(self.ventana)
        self.inferior.pack(side=TOP)
    
        self.btn1 = Button(self.inferior, text="'más pequeña'", bg="deeppink", fg="white", font=("Arial 10 bold"), height=3, width=15, command=operaciones.inciso_a)
        self.btn2 = Button(self.inferior, text="Primeros 5\ncaracteres", bg="dodgerblue3", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_b)
        self.btn3 = Button(self.inferior, text="Últimos 6\ncaracteres", bg="darkorchid4", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_c)
        self.btn4 = Button(self.inferior, text="Posiciones\nPares", bg="lightpink4", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_d)
        self.btn5 = Button(self.inferior, text="'o repra'", bg="turquoise4", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_e)
        self.btn6 = Button(self.inferior, text="Cuántas 'a' y 'á'", bg="mediumpurple3", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_f)
        self.btn1.grid(column=0, row=1, padx=5, pady=5)
        self.btn2.grid(column=1, row=1, padx=5, pady=5)
        self.btn3.grid(column=0, row=2, padx=5, pady=5)
        self.btn4.grid(column=1, row=2, padx=5, pady=5)
        self.btn5.grid(column=0, row=3, padx=5, pady=5)
        self.btn6.grid(column=1, row=3, padx=5, pady=5)

def main(): 
    ventana = Tk()
    ventana.geometry('500x450')
    ventana.title("Rebanadas")
    app = Interfaz(ventana)
    ventana.mainloop()


if __name__ == '__main__':
    main()
