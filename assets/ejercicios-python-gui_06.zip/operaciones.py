'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Dadas las cadenas:
str1 = '   Quizá haya enemigos de mis opiniones,    '
str2 = ' pero yo mismo  puedo ser también enemigo de mis opiniones.  '
str3 = ', si espero un rato,'
a) Mostrar el carácter que se encuentra en la posición 7 de cada cadena, separados por un espacio.
b) Usar una operación que obtenga el carácter que se encuentra en la última posición de str3.
c) Eliminar los blancos a izquierda y derecha de str1
d) Obtener una rebanada de str1 que contenga la palabra "quizá" (con la "q" en minúscula), al mismo tiempo que se eliminan los espacios en blanco a la izquierda.
e) Armar la expresión 'Quizá haya enemigos de mis opiniones, pero yo mismo, si espero un rato, puedo ser también enemigo de mis opiniones.'
f) Obtener el texto 'si espero UN RATO' a partir de str3.
''' 

str1 = '   Quizá haya enemigos de mis opiniones,    '
str2 = ' pero yo mismo  puedo ser también enemigo de mis opiniones.  '
str3 = ', si espero un rato,'

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana
	
    def inciso_a(self):
        r=    #completar con la instrucción necesaria para que la variable r contenga el carácter en la posición 8 de cada cadena, separados por espacio
        self.ventana.resultado.configure(text=r)

    def inciso_b(self):
        r=    #completar con la instrucción necesaria para que la variable r contenga el último carácter de str3
        self.ventana.resultado.configure(text=r)

    def inciso_c(self):
        r=    #completar con la instrucción necesaria para eliminar los blancos a izquierda y derecha de str1 y almacenar el resultado en la variable r 
        self.ventana.resultado.configure(text=r)

    def inciso_d(self):
        r=    #completar con la instrucción necesaria para que la variable r contenga una rebanada de str1 que contenga la palabra "quizá" (con la "q" en minúscula)
        self.ventana.resultado.configure(text=r)

    def inciso_e(self):
        r=    #completar con la instrucción necesaria para que la variable r contenga la frase 'Quizá haya enemigos de mis opiniones, pero yo mismo, si espero un rato, puedo ser también enemigo de mis opiniones.'
        self.ventana.resultado.configure(text=r)

    def inciso_f(self):
        r=    #completar con la instrucción necesaria para que la variable r contenga 'si espero UN RATO' a partir de str3
        self.ventana.resultado.configure(text=r)
