'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Dadas las cadenas:
a = '  Python es un lenguaje amigable para empezar a aprender programación   '
b = '        nociones básicas de  '
¿Cuál es la longitud de la cadena a?
¿En qué posición se encuentra  la palabra 'amigable'?
¿Cómo harías para obtener una rebanada de la cadena a que contenga la palabra "Programación" (con la "p" en mayúscula)
¿Cómo harías para eliminar los blancos a izquierda y derecha de b?
¿Cómo harías para armar la expresión 'Python es un lenguaje amigable para empezar a aprender nociones básicas de programación'?
Convertí la cadena 'amigable' a mayúsculas y cambiala en la expresión del punto e). Deberá quedar: 'Python es un lenguaje AMIGABLE para empezar a aprender nociones básicas de programación'
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

		
    def primeraOpcion(self):
        a = '  Python es un lenguaje amigable para empezar a aprender programación   '
        r=   #completar con la instrucción necesaria para que la variable r contenga la longitud de la cadena a
        self.ventana.resultado.configure(text=r)

    def segundaOpcion(self):
        a = '  Python es un lenguaje amigable para empezar a aprender programación   '
        r=   #completar con la instrucción necesaria para que la variable r contenga la posición de la palabra 'amigable'
        self.ventana.resultado.configure(text=r)

    def terceraOpcion(self):
        a = '  Python es un lenguaje amigable para empezar a aprender programación   '
        r=   #completar con la instrucción necesaria para que la variable r contenga una rebanada de la cadena a con la palabra “Programación” (con la “p” en mayúscula)
        self.ventana.resultado.configure(text=r)

    def cuartaOpcion(self):
        a = '  Python es un lenguaje amigable para empezar a aprender programación   '
        b = '        nociones básicas de  '
        r=   #completar con la instrucción necesaria para eliminar los blancos a izquierda y derecha de b y almacenar el resultado en la variable r 
        self.ventana.resultado.configure(text=r)

    def quintaOpcion(self):
        a = '  Python es un lenguaje amigable para empezar a aprender programación   '
        b = '        nociones básicas de  '
        r=   #completar con la instrucción necesaria para que la variable r contenga la expresión 'Python es un lenguaje amigable para empezar a aprender nociones básicas de programación'?
        self.ventana.resultado.configure(text=r)

    def sextaOpcion(self):
        a = '  Python es un lenguaje amigable para empezar a aprender programación   '
        b = '        nociones básicas de  '
        r=   #completar con la instrucción necesaria para que la variable r contenga 'Python es un lenguaje AMIGABLE para empezar a aprender nociones básicas de programación'
        self.ventana.resultado.configure(text=r)
