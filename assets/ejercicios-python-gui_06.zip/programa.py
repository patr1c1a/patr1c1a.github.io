'''
Atención: No modificar este archivo.
Abrir el archivo operaciones.py y, de acuerdo a la consigna dada, completar únicamente donde aparecen comentarios indicados con #
Luego ejecutar este programa python.
'''


from tkinter import *
from operaciones import *

class Interfaz:
    def __init__(self, ventana):
        self.ventana = ventana
        operaciones=Operaciones(self)
        
        self.a = Label(ventana, text='"  Python es un lenguaje amigable para empezar a aprender programación   "', font=("Verdana", 13), bg="thistle3")
        self.a.pack(padx=15, pady=(45,5), side=TOP)
        self.b = Label(ventana, text='"        nociones básicas de  "', font=("Verdana", 13), bg="thistle3")
        self.b.pack(padx=15, pady=(5,20), side=TOP)
        self.resultado = Label(ventana, text="", width=30, height=2, font=("Arial", 14), bg="white")
        self.resultado.pack(padx=15, pady=(5,25), side=TOP)

        self.inferior=Frame(self.ventana)
        self.inferior.pack(side=TOP)
        self.inferior.configure(backgroun="thistle3")
    
        self.btn1 = Button(self.inferior, text="Longitud de a", bg="palevioletred1", fg="white", font=("Arial 10 bold"), height=3, width=15, command=operaciones.primeraOpcion)
        self.btn2 = Button(self.inferior, text="Posición de\n'amigable'", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.segundaOpcion)
        self.btn3 = Button(self.inferior, text="Programación", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.terceraOpcion)
        self.btn4 = Button(self.inferior, text="Eliminar\nblancos", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.cuartaOpcion)
        self.btn5 = Button(self.inferior, text="Expresión\nCompleta", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.quintaOpcion)
        self.btn6 = Button(self.inferior, text="AMIGABLE", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.sextaOpcion)
        self.btn1.grid(column=0, row=1, padx=5, pady=5)
        self.btn2.grid(column=1, row=1, padx=5, pady=5)
        self.btn3.grid(column=0, row=2, padx=5, pady=5)
        self.btn4.grid(column=1, row=2, padx=5, pady=5)
        self.btn5.grid(column=0, row=3, padx=5, pady=5)
        self.btn6.grid(column=1, row=3, padx=5, pady=5)

def main(): 
    ventana = Tk()
    ventana.geometry('700x480')
    ventana.configure(background="thistle3")
    ventana.title("Manipulando strings")
    app = Interfaz(ventana)
    ventana.mainloop()


if __name__ == '__main__':
    main()
