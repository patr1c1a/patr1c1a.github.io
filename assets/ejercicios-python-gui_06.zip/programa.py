'''
Atención: No modificar este archivo.
Abrir el archivo operaciones.py y, de acuerdo a la consigna dada, completar únicamente donde aparecen comentarios indicados con #
Luego ejecutar este programa python.
'''


from tkinter import *
from operaciones import *

class Interfaz:
    def __init__(self, ventana):
        self.ventana = ventana
        operaciones=Operaciones(self)
        
        self.str1 = Label(ventana, text='"  Quizá haya enemigos de mis opiniones,    "', font=("Verdana", 13), bg="thistle3")
        self.str1.pack(padx=15, pady=(30,5), side=TOP)
        self.str2 = Label(ventana, text='"        pero yo mismo  puedo ser también enemigo de mis opiniones.  "', font=("Verdana", 13), bg="thistle3")
        self.str2.pack(padx=15, pady=5, side=TOP)
        self.str3 = Label(ventana, text='", si espero un rato,"', font=("Verdana", 13), bg="thistle3")
        self.str3.pack(padx=15, pady=(5,20), side=TOP)
        self.resultado = Label(ventana, text="", width=40, height=3, font=("Arial 14 underline"), bg="white", wraplength=400, justify="center")
        self.resultado.pack(padx=15, pady=(5,25), side=TOP)

        self.inferior=Frame(self.ventana)
        self.inferior.pack(side=TOP)
        self.inferior.configure(background="thistle3")
    
        self.btn1 = Button(self.inferior, text="Caracteres en\nposición 7", bg="palevioletred1", fg="white", font=("Arial 10 bold"), height=3, width=15, command=operaciones.inciso_a)
        self.btn2 = Button(self.inferior, text="Último carácter\nde str3", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_b)
        self.btn3 = Button(self.inferior, text="Eliminar blancos", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_c)
        self.btn4 = Button(self.inferior, text="Obtener\n'quizá", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_d)
        self.btn5 = Button(self.inferior, text="Expresión\nCompleta", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_e)
        self.btn6 = Button(self.inferior, text="UN RATO", bg="palevioletred1", fg="white", font=("Arial 10 bold"),height=3, width=15, command=operaciones.inciso_f)
        self.btn1.grid(column=0, row=1, padx=5, pady=5)
        self.btn2.grid(column=1, row=1, padx=5, pady=5)
        self.btn3.grid(column=0, row=2, padx=5, pady=5)
        self.btn4.grid(column=1, row=2, padx=5, pady=5)
        self.btn5.grid(column=0, row=3, padx=5, pady=5)
        self.btn6.grid(column=1, row=3, padx=5, pady=5)

def main(): 
    ventana = Tk()
    ventana.geometry('700x480')
    ventana.configure(background="thistle3")
    ventana.title("Manipulando strings")
    app = Interfaz(ventana)
    ventana.mainloop()


if __name__ == '__main__':
    main()
