'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Dadas las variables str1 = "Juan" y str2 = "Pérez", como harías para mostrar:
Las dos cadenas concatenadas, mostrando apellido y nombre. Ejemplo: "Pérez Juan"
Las dos cadenas concatenadas pero separadas por ", ". Ejemplo: "Pérez, Juan"
Nombre y apellido
¡Bienvenido, Juan Pérez!
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

        
		
    def primeraOpcion(self):
        str1 = "Juan"
        str2 = "Pérez"
        s=    #completar con la instrucción necesaria para que la variable s guarde la concatenación de apellido y nombre
        self.ventana.resultado.configure(text=s)

    def segundaOpcion(self):
        str1 = "Juan"
        str2 = "Pérez"
        s=    #completar con la instrucción necesaria para la variable s guarde la concatenación de apellido y nombre, separadas por ", "
        self.ventana.resultado.configure(text=s)

    def terceraOpcion(self):
        str1 = "Juan"
        str2 = "Pérez"
        s=    #completar con la instrucción necesaria para la variable s guarde la concatenación de nombre y apellido
        self.ventana.resultado.configure(text=s)

    def cuartaOpcion(self):
        str1 = "Juan"
        str2 = "Pérez"
        s=    #completar con la instrucción necesaria para la variable s guarde "¡Bienvenido, Juan Pérez!"
        self.ventana.resultado.configure(text=s)
