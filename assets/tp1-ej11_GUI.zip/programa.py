'''
Atención: No modificar este archivo.
Abrir el archivo operaciones.py  y, de acuerdo a la consigna dada, completar únicamente donde aparecen comentarios indicados con #
Luego ejecutar este programa python.
'''


from tkinter import *
from operaciones import *

class Interfaz:
    def __init__(self, ventana):
        self.ventana = ventana
		operaciones=Operaciones(self)
        self.superior=Frame(self.ventana)
        self.superior.pack(side=TOP)
        self.numero = Label(self.superior, text='str1: "Juan"\nstr2: "Pérez"', font=("Arial Bold", 17))
        self.numero.pack(padx=15, pady=45, side=LEFT)
        self.resultado = Label(self.superior, text="cadena: ", width=25, height=2, bg="white", font=("Arial", 12))
        self.resultado.pack(padx=15, pady=45, side=RIGHT)
        self.inferior=Frame(self.ventana)
        self.inferior.pack(side=TOP)
        self.btn1 = Button(self.inferior, text="[Apellido Nombre]", bg="pink", height=2, width=30, command=operaciones.primeraOpcion)
        self.btn2 = Button(self.inferior, text="[Apellido, Nombre]", bg="light blue", height=2, width=30, command=operaciones.segundaOpcion)
        self.btn3 = Button(self.inferior, text="[Nombre Apellido]", bg="light green", height=2, width=30, command=operaciones.terceraOpcion)
        self.btn4 = Button(self.inferior, text="¡Bienvenido, [Nombre Apellido]!", bg="light yellow", height=2, width=30, command=operaciones.cuartaOpcion)
        self.btn1.pack()
        self.btn2.pack()
        self.btn3.pack()
        self.btn4.pack()

def main(): 
    ventana = Tk()
    ventana.geometry('500x400')
    ventana.title("Manipulando strings")
    app = Interfaz(ventana)
    ventana.mainloop()


if __name__ == '__main__':
    main()
