'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Teniendo las siguientes variables:
cadena1 = "¡Bienvenidos!"
cadena2 = " esto es"
cadena3 = " IPI"
cadena4 = " lo más divertido"
cadena5 = " de primer año"
cadena6 = " ..."
Construir la cadena "Bienvenidos esto es de primer año lo más divertido... IPI".
¿En qué posición de la cadena anterior está la palabra "primer"?
Buscar la primera posición en que aparece la letra "e" en cadena1.
Si buscás la letra "n" en cadena1, ¿qué resultado dará? ¿Por qué?
Obtener True o False para saber si cadena6 contiene espacios.
¿Qué resultado se obtiene al buscar la letra "d" en cadena4[:6]? ¿Por qué?
¿Cuántos espacios tiene la cadena construida en el punto a?
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

        
		
    def primeraOpcion(self):
        cadena1 = "¡Bienvenidos!"
        cadena2 = " esto es"
        cadena3 = " IPI"
        cadena4 = " lo más divertido"
        cadena5 = " de primer año"
        cadena6 = " ..."
        s=     #completar con la instrucción necesaria para que la variable s guarde la cadena "Bienvenidos esto es de primer año lo más divertido... IPI"
        self.ventana.resultado.configure(text=s)

    def segundaOpcion(self):
        cadena1 = "¡Bienvenidos!"
        cadena2 = " esto es"
        cadena3 = " IPI"
        cadena4 = " lo más divertido"
        cadena5 = " de primer año"
        cadena6 = " ..."
        #si es necesario, crear una variable
        
        s=                          #completar con la instrucción necesaria para que la variable s guarde en qué posición de la cadena completa está la palabra "primer"
        self.ventana.resultado.configure(text=s)

    def terceraOpcion(self):
        cadena1 = "¡Bienvenidos!"
        s=cadena1.find("e")         #completar con la instrucción necesaria para que la variable s guarde la primera posición en que aparece la letra "e" en cadena1
        self.ventana.resultado.configure(text=s)

    def cuartaOpcion(self):
        cadena1 = "¡Bienvenidos!"
        s=                          #completar con la instrucción necesaria para que la variable s guarde el resultado de buscar la "n" en cadena1
        self.ventana.resultado.configure(text=s)

    def quintaOpcion(self):
        cadena6 = " ..."
        s=                          #completar con la instrucción necesaria para que la variable s guarde True o False dependiendo de si cadena6 contiene espacios
        self.ventana.resultado.configure(text=s)

    def sextaOpcion(self):
        cadena4 = " lo más divertido"
        s=                          #completar con la instrucción necesaria para que la variable s guarde la posición de la letra "d" en cadena4[:6]
        self.ventana.resultado.configure(text=s)

    def septimaOpcion(self):
        cadena1 = "¡Bienvenidos!"
        cadena2 = " esto es"
        cadena3 = " IPI"
        cadena4 = " lo más divertido"
        cadena5 = " de primer año"
        cadena6 = " ..."
        #si es necesario, crear una variable
        
        s=                          #completar con la instrucción necesaria para que la variable s guarde cuántos espacios tiene la cadena "Bienvenidos esto es de primer año lo más divertido... IPI"
        self.ventana.resultado.configure(text=s)
