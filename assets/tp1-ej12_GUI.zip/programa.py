'''
Atención: No modificar este archivo.
Abrir el archivo operaciones.py  y, de acuerdo a la consigna dada, completar únicamente donde aparecen comentarios indicados con #
Luego ejecutar este programa python.
'''


from tkinter import *
from operaciones import *

class Interfaz:
    def __init__(self, ventana):
        self.ventana = ventana
        operaciones=Operaciones(self)
        
        self.resultado = Label(ventana, text="", width=35, height=2, bg="white", font=("Arial", 12))
        self.resultado.pack(padx=15, pady=10, side=TOP, fill=BOTH)
        
        self.izquierda=Frame(self.ventana)
        self.izquierda.pack(side=LEFT)
        self.cadenas = Label(self.izquierda, text='cadena1: "¡Bienvenidos!"\ncadena2: " esto es"\ncadena3: " IPI"\ncadena4: " lo más divertido"\ncadena5: " de primer año"\ncadena6: " ..."', justify=LEFT, font=("Verdana", 15))
        self.cadenas.pack(padx=20)

        self.derecha=Frame(self.ventana)
        self.derecha.pack(padx=20, side=LEFT)      
        self.btn1 = Button(self.derecha, text="Cadena completa", bg="moccasin", height=2, width=30, command=operaciones.primeraOpcion)
        self.btn2 = Button(self.derecha, text="Posición de 'primer'\nen la cadena completa", bg="moccasin", height=2, width=30, command=operaciones.segundaOpcion)
        self.btn3 = Button(self.derecha, text="Dónde está 'e' en cadena1", bg="moccasin", height=2, width=30, command=operaciones.terceraOpcion)
        self.btn4 = Button(self.derecha, text="Dónde está 'n' en cadena1", bg="moccasin", height=2, width=30, command=operaciones.cuartaOpcion)
        self.btn5 = Button(self.derecha, text="¿cadena6 tiene espacios?", bg="moccasin", height=2, width=30, command=operaciones.quintaOpcion)
        self.btn6 = Button(self.derecha, text="Dónde está 'd' en cadena4[:6]", bg="moccasin", height=2, width=30, command=operaciones.sextaOpcion)
        self.btn7 = Button(self.derecha, text="Cantidad de espacios\nen la cadena completa", bg="moccasin", height=2, width=30, command=operaciones.septimaOpcion)
        self.btn1.pack()
        self.btn2.pack()
        self.btn3.pack()
        self.btn4.pack()
        self.btn5.pack()
        self.btn6.pack()
        self.btn7.pack()

def main(): 
    ventana = Tk()
    ventana.geometry('600x450')
    ventana.resizable(width=False, height=False)
    ventana.title("Manipulando strings")
    app = Interfaz(ventana)
    ventana.mainloop()


if __name__ == '__main__':
    main()
