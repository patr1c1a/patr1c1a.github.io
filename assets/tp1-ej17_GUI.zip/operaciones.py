'''Completar donde se indica con #, de acuerdo a la siguiente consigna:
Si tenemos la cadena texto = 'No sé bien qué día es hoy', indicá cómo obtener:
La cadena 'qué día' a partir de la variable texto.
Los primeros 5 caracteres de texto.
Los últimos 5 caracteres de texto.
Los caracteres ubicados en las posiciones pares de texto.
La cadena 'ye né' a partir de texto.
Cuántas ocurrencias de la letra 'e' existen en texto (incluir la 'e' con y sin acentos)
''' 

class Operaciones:
    def __init__(self, ventana):
        self.ventana=ventana

		
    def primeraRebanada(self):
        texto = 'No sé bien qué día es hoy'
        r=   #completar con la instrucción necesaria para que la variable r contenga la rebanada 'qué día' a partir de la variable texto
        self.ventana.resultado.configure(text=r)

    def segundaRebanada(self):
        texto = 'No sé bien qué día es hoy'
        r=   #completar con la instrucción necesaria para que la variable r contenga los primeros 5 caracteres de la variable texto
        self.ventana.resultado.configure(text=r)

    def terceraRebanada(self):
        texto = 'No sé bien qué día es hoy'
        r=   #completar con la instrucción necesaria para que la variable r contenga los últimos 5 caracteres de la variable texto
        self.ventana.resultado.configure(text=r)

    def cuartaRebanada(self):
        texto = 'No sé bien qué día es hoy'
        r=   #completar con la instrucción necesaria para que la variable r contenga los caracteres pares de la variable texto
        self.ventana.resultado.configure(text=r)

    def quintaRebanada(self):
        texto = 'No sé bien qué día es hoy'
        r=   #completar con la instrucción necesaria para que la variable r contenga la rebanada 'ye né' a partir de la variable texto
        self.ventana.resultado.configure(text=r)

    def cantidadE(self):
        texto = 'No sé bien qué día es hoy'
        c=   #completar con la instrucción necesaria para que la variable c contenga la cantidad de 'e' y 'é' de la cadena guardada en texto
        self.ventana.resultado.configure(text=c)
